function hf=figure1
hf=figure('units','normalized','position',[0.03 0.073 0.93 0.8]);